const url = 'https://swapi.dev/api';

// default прави HTTP METHOD GET

// fetch връща Promise от response

// Promise chaining 
// fetch(`${url}/people/1`)
//     .then((response) => {
//         // console.log(response);
//         // конвертираме в JSON
//         return response.json();
//     })
//     .then(data => {
//         console.log(data);
//     })
//     //         .then(data => {
//     //             console.log(data);
//     //         })
//     //         .catch(err => console.log(err));
//     // })
//     .catch(error => {
//         console.log('Something went wrong');
//     });



// fetch(`${url}/people/1`)
//     .then(response => response.json())
//     .then(data => console.log(data))
//     .catch(error => console.log('Something went wrong'));

// // Using server to get books
const booksUrl = 'http://localhost:3030/jsonstore/books';
// fetch(`http://localhost:3030/jsonstore/books`)
//     .then(res => res.json())
//     .then(data => console.log(data))
//     .catch(error => console.log(error))

// // Create book
// fetch(booksUrl, {
//     method: 'POST',
//     headers: {
//         'content-type': 'applicaiton/json'
//     },
//     body: JSON.stringify({
//         title: 'Chronicles of Narnia',
//         author: 'C.S.Lewis',
//     })
// })
//     .then(res => res.json())
//     .then(data => console.log(data))
//     .catch(err => console.log(err));

// Edit book
// The Lion, the Witch and the Wardrobe
// fetch(`${booksUrl}/6ed58347-b8c5-4ca3-80e7-1fbe01e6f399`, {
//     method: 'PUT',
//     headers: {
//         'content-type': 'application/json',
//     },
//     body: JSON.stringify({
//         "title": "Harry Potter and the Philosopher's Stone, The Lion, the Witch and the Wardrobe",
//         "Author": "J.K.Howling",
//         "_id": "6ed58347-b8c5-4ca3-80e7-1fbe01e6f399"
//     })
// })

// Delete book
// fetch(`${booksUrl}/1107f646-301b-4713-ac93-341104943484`, {
//     method: 'DELETE',
// })
//     .fetch(res => console.log(res))
//     .catch(err => console.log(err));