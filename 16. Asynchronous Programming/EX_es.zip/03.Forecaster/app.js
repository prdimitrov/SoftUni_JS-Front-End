function attachEvents() {
    // Base URL
    const baseUrl = 'http://localhost:3030/jsonstore/forecaster';

    const locationElement = document.getElementById('location');
    const submitButton = document.getElementById('submit');
    const forecastElement = document.getElementById('forecast');
    const currentElement = document.getElementById('current');

    const weatherSymbol = {
        'Sunny': '☀',
        'Partly sunny': '⛅',
        'Overcast': '☁',
        'Rain': '☂',
        'Degrees': '°',
    };

    submitButton.addEventListener('click', () => {
        fetch(`${baseUrl}/locations`)
            .then(res => res.json())
            .then(locationsData => {
                const { code } = locationsData.find(location => location.name === locationElement.value);

                return Promise.all([
                    fetch(`${baseUrl}/today/${code}`).then(res => res.json()),
                    fetch(`${baseUrl}/upcoming/${code}`).then(res => res.json()),
                ]);
            })
            .then(([todayData, upcomingData]) => {
                console.log(todayData);
                forecastElement.style.display = 'block';

                const symbolSpanElement = document.createElement('span');
                symbolSpanElement.classList.add('condition');
                symbolSpanElement.classList.add('symbol');
                symbolSpanElement.textContent = weatherSymbol[todayData.forecast.condition];

                const anotherSpan = document.createElement('span');
                anotherSpan.innerHTML = `
                    <span class="condition">
                        <span class="forecast-data">${todayData.name}</span>
                        <span class="forecast-data">${todayData.forecast.low}/${todayData.forecast.high}</span>
                        <span class="forecast-data">${todayData.forecast.condition}</span>
                    </span>
                `;

                const forecastsElement = document.createElement('div');
                forecastsElement.classList.add('forecasts');
                forecastsElement.appendChild(symbolSpanElement);
                forecastsElement.appendChild(anotherSpan);

                currentElement.appendChild(forecastsElement);
            })
            .catch(error => console.error('Error:', error));
    });
}

attachEvents();
