// Endpoint
const baseUrl = 'http://localhost:3030/jsonstore/games/';
const gameNameInputElement = document.getElementById('g-name');
const typeInputElement = document.getElementById('type');
const playersInputElement = document.getElementById('players');
const addGameButton = document.getElementById('add-game');
//TODO: The edit button is disabled by default!!!!!
const editGameButton = document.getElementById('edit-game');
const loadGamesButton = document.getElementById('load-games');
const gamesListElement = document.getElementById('games-list');

const formElement = document.getElementById('form');

loadGamesButton.addEventListener('click', loadGames);

addGameButton.addEventListener('click', (event) => {
    event.preventDefault;
    const game = getInputData();
    fetch(baseUrl, {
        method: 'POST',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify(game)
    }).then(res => {
        clearInputFields();
        return loadGames();
    })

});

// gamesListElement.addEventListener('click', deleteGame);

editGameButton.addEventListener('click', editGame);

async function loadGames() {
    const response = await fetch(baseUrl);
    const gamesResultList = await response.json();
    // Remove games from the games list.
    gamesListElement.innerHTML = '';
    const gameListFragment = document.createDocumentFragment();

    Object.values(gamesResultList).forEach(game => {
        gameListFragment.appendChild(createGameElement(game));
    });
    gamesListElement.appendChild(gameListFragment);

    function createGameElement(game) {
        const boardGame = document.createElement('div');
        boardGame.setAttribute('class', 'board-game');
        boardGame.setAttribute('data-id', game._id);

        const contentElement = document.createElement('div');
        contentElement.setAttribute('class', 'content');

        const namePElement = document.createElement('p');
        namePElement.textContent = game.name;
        const maxPlayersPElement = document.createElement('p');
        maxPlayersPElement.textContent = game.players;
        const typePElement = document.createElement('p');
        typePElement.textContent = game.type;

        contentElement.appendChild(namePElement);
        contentElement.appendChild(maxPlayersPElement);
        contentElement.appendChild(typePElement);

        boardGame.appendChild(contentElement);

        const buttonsContainer = document.createElement('div');
        buttonsContainer.setAttribute('class', 'buttons-container');

        const changeButton = document.createElement('button');
        changeButton.setAttribute('class', 'change-btn');
        changeButton.textContent = 'Change';
        changeButton.addEventListener('click', (e) => changeGame(e, game));
        const deleteButton = document.createElement('button');
        deleteButton.setAttribute('class', 'delete-btn');
        deleteButton.textContent = 'Delete';

        deleteButton.addEventListener('click', (e) => deleteGame(e, game));

function deleteGame(e, game) {
    if (e.target.tagName !== 'BUTTON' || !e.target.classList.contains('delete-btn')) {
        return;
    }
    const gameElement = e.target.parentElement.parentElement;
    const gameId = gameElement.getAttribute('data-id');
    fetch(`${baseUrl}/${gameId}`, {
        method: 'DELETE'
    }).then(res => {
        gameElement.remove();
    });
}

        buttonsContainer.appendChild(changeButton);
        buttonsContainer.appendChild(deleteButton);

        boardGame.appendChild(buttonsContainer);

        return boardGame;
    }

}

function changeGame(e, game) {
    const gameElement = e.currentTarget.parentElement.parentElement;
    gameElement.remove();
    gameNameInputElement.value = game.name;
    typeInputElement.value = game.type;
    playersInputElement.value = game.players;
    formElement.setAttribute('data-id', game._id);
    editGameButton.removeAttribute('disabled');
    // TODO: REMOVE the setAttribute in case of problems!
    addGameButton.setAttribute('disabled', 'disabled');
}

function editGame() {
    const game = getInputData();
    const gameId = formElement.getAttribute('data-id');
    formElement.removeAttribute('data-id');
    fetch(`${baseUrl}/${gameId}`, {
        method: 'PUT',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify({ ...game, _id: gameId })
    }).then(res => {
        loadGames();
        editGameButton.setAttribute('disabled', 'disabled');
        addGameButton.removeAttribute('disabled');
        clearInputFields();
    }).done();
}

// function deleteGame(e) {
//     if (e.target.tagName !== 'BUTTON' || !e.target.classList.contains('delete-btn')) {
//         return;
//     }
//     const gameElement = e.target.parentElement.parentElement;
//     const gameId = gameElement.getAttribute('data-id');
//     fetch(`${baseUrl}/${gameId}`, {
//         method: 'DELETE'
//     }).then(res => {
//         gameElement.remove();
//     });
// }

function getInputData() {
    return {
        name: gameNameInputElement.value,
        players: playersInputElement.value,
        type: typeInputElement.value
    };
}

function clearInputFields() {
    gameNameInputElement.value = '';
    typeInputElement.value = '';
    playersInputElement.value = '';
}