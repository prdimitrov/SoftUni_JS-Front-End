// Endpoint
const baseUrl = 'http://localhost:3030/jsonstore/tasks/';
const form = document.getElementById('form');
const nameInputElement = document.getElementById('name');
const numberOfDaysInputElement = document.getElementById('num-days');
const fromDateInputElement = document.getElementById('from-date');
const addButton = document.getElementById('add-vacation');
const editButton = document.getElementById('edit-vacation');
const loadButton = document.getElementById('load-vacations');

const vacationsList = document.getElementById('list');
// const vacationsList = document.getElementById('confirmed-vacantions');

loadButton.addEventListener('click', loadVacations);
addButton.addEventListener('click', addVacation);
editButton.addEventListener('click', (e) => {
    e.preventDefault();
    if (nameInputElement.value == '' ||
        numberOfDaysInputElement.value == '' ||
        fromDateInputElement.value == '') {
        return;
    }
    // console.log(form.getAttribute('data-id'));
    const targetId = form.getAttribute('data-id');
    fetch(`${baseUrl}/${targetId}`, {
        method: 'PUT',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify({
            name: nameInputElement.value,
            days: numberOfDaysInputElement.value,
            date: fromDateInputElement.value,
            _id: targetId
        })
    })
        .then(() => {
            nameInputElement.value = '';
            numberOfDaysInputElement.value = '';
            fromDateInputElement.value = '';
        })
        .then(loadVacations);
    addButton.removeAttribute('disabled');
    editButton.setAttribute('disabled', disabled);
}

);


async function loadVacations() {
    // e.preventDefault();
    clearAllSections();
    try {
        const response = await fetch(baseUrl);
        const vacations = await response.json();
        for (const vacation of Object.values(vacations)) {
            const divElement = document.createElement('div');
            divElement.setAttribute('class', 'container');
            const h2Element = document.createElement('h2');
            h2Element.textContent = vacation.name;
            divElement.appendChild(h2Element);
            const h3Element = document.createElement('h3');
            h3Element.textContent = vacation.date;
            divElement.appendChild(h3Element);
            const daysH3Element = document.createElement('h3');
            daysH3Element.textContent = vacation.days;
            divElement.appendChild(daysH3Element);

            // Create buttons for the div element
            const changeButton = document.createElement('button');
            changeButton.setAttribute('class', 'change-btn');
            changeButton.textContent = 'Change';
            // TODO: Change button event listener!
            changeButton.addEventListener('click', (e) => {
                nameInputElement.value = vacation.name;
                numberOfDaysInputElement.value = vacation.days;
                fromDateInputElement.value = vacation.date;
                let targetID = vacation._id;
                editButton.disabled = false;
                addButton.disabled = true;
                form.setAttribute('data-id', targetID);
                // Remove the element from the DOM
                vacationsList.removeChild(divElement);
            });



            const doneButton = document.createElement('button');
            doneButton.setAttribute('class', 'done-btn');
            doneButton.textContent = 'Done';

            // Append buttons to divElement
            divElement.appendChild(changeButton);
            divElement.appendChild(doneButton);

            vacationsList.appendChild(divElement);
            clearInputFields();

        }
    } catch (err) {
        console.log(err);
    }

}

function addVacation(e) {
    e.preventDefault();
    if (nameInputElement.value == '' ||
        numberOfDaysInputElement.value == '' ||
        fromDateInputElement.value == '') {
        clearInputFields();
        return;
    }
    const newVacation = fetch(baseUrl, {
        method: 'POST',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify({
            name: nameInputElement.value,
            days: numberOfDaysInputElement.value,
            date: fromDateInputElement.value
        })
    }).then(loadVacations)
        .catch(console.error);


    clearInputFields();
}

function clearInputFields() {
    nameInputElement.value = '';
    numberOfDaysInputElement.value = '';
    fromDateInputElement.value = '';
}

function clearAllSections() {
    document.getElementById('list').innerHTML = '';
}