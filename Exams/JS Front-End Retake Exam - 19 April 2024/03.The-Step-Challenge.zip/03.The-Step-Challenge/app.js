// Endpoint
const baseURL = 'http://localhost:3030/jsonstore/records/';

const loadButton = document.getElementById('load-records');
const list = document.getElementById('list');
const pnameInput = document.getElementById('p-name');
const stepsInput = document.getElementById('steps');
const caloriesInput = document.getElementById('calories');
const addButton = document.getElementById('add-record');
const editButton = document.getElementById('edit-record');

let currentRecordId = null;

// Load button event listener
loadButton.addEventListener('click', loadRecords);

// Edit button event listener
editButton.addEventListener('click', async () => {
    // Get data from the inputs
    const { name, steps, calories } = getInputData();

    const response = await fetch(`${baseURL}/${currentRecordId}`, {
        method: 'PUT', 
        headers: {
            'content-type': 'application/json'
        }, 
        body: JSON.stringify({
            _id: currentRecordId, 
            name, 
            steps, 
            calories,
        })
    });

    if (!response.ok) {
        return;
    }

    // Load the records
    loadRecords();

    // Deactivating the edit button
    editButton.setAttribute('disabled', 'disabled');
    // Activating the add button
    addButton.removeAttribute('disabled');
    // Clearing the current record id
    currentRecordId = null;
    // Clearing the input fields
    clearInputData();

});

addButton.addEventListener('click', async () => {
    const newRecord = getInputData();

    // Create a POST Request
    const response = await fetch(baseURL, {
        method: 'POST', 
        headers: {
            'content-type': 'application/json'
        }, 
        body: JSON.stringify(newRecord),
    });
    if (!response.ok) {
        return;
    }

    clearInputData();
    
    await loadRecords();
});

async function loadRecords() {
    const response = await fetch(baseURL);
    const data = await response.json();

    list.innerHTML = '';

    for (const record of Object.values(data)) {
        const recordLiElement = document.createElement('li');
        recordLiElement.setAttribute('class', 'record');

        const divElement = document.createElement('div');
        divElement.setAttribute('class', 'info');

        const namePElement = document.createElement('p');
        namePElement.textContent = record.name;
        const stepsPElement = document.createElement('p');
        stepsPElement.textContent = record.steps;
        const caloriesPElement = document.createElement('p');
        caloriesPElement.textContent = record.calories;

        divElement.appendChild(namePElement);
        divElement.appendChild(stepsPElement);
        divElement.appendChild(caloriesPElement);

        recordLiElement.appendChild(divElement);

        const buttonsWrapper = document.createElement('div');
        buttonsWrapper.setAttribute('class', 'btn-wrapper');

        const changeBtn = document.createElement('button');
        changeBtn.setAttribute('class', 'change-btn');
        changeBtn.textContent = 'Change';
        buttonsWrapper.appendChild(changeBtn);

        const deleteBtn = document.createElement('button');
        deleteBtn.setAttribute('class', 'delete-btn');
        changeBtn.textContent = 'Delete';
        buttonsWrapper.appendChild(deleteBtn);

        recordLiElement.appendChild(buttonsWrapper);

        // Attach element to the dom
        list.appendChild(recordLiElement);

        // Action for the changeBtn
        changeBtn.addEventListener('click', () => {
            currentRecordId = record._id;

            // Populating the input
            pnameInput.value = record.name;
            stepsInput.value = record.steps;
            caloriesInput.value = record.calories;
            // Activating the edit button
            editButton.removeAttribute('disabled');
            // Deactivating the add button
            addButton.setAttribute('disabled', 'disabled');
            // Remove record from the list
            recordLiElement.remove();
        });

        // Attach on delete
        deleteBtn.addEventListener('click', async () => {
            // DELETE HTTP REQUEST
            const response = await fetch(`${baseURL}/${record._id}`, {
                method: 'DELETE'
            });

            // TODO: IN CASE OF PROBLEMS, REMOVE THIS!
            if (!response.ok) {
                return;
            }
            // Remove from the list
            recordLiElement.remove();
        });

    }
}

function getInputData() {
    const name = pnameInput.value;
    const steps = stepsInput.value;
    const calories = caloriesInput.value;
    return { name, steps, calories };
}

function clearInputData() {
    pnameInput.value = '';
    stepsInput.value = '';
    caloriesInput.value = '';
}